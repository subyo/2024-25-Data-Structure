#2.ssoru doğum günün kutlu olsun sözcükleri ile astring oluşturma
astring = "Doğum günün kutlu olsun "
test=astring
print(test)

###################################################################################

#3.soru oluşturulan dize
dize= "      ,        "

#dizeyi  ”,” karakterine göre ikiye ayırma 
ayrik_dizeler = dize.split (" , ")

#ayrılan dizeyi bir listeye koyma
Ist = ayrik_dizeler

#sonucu kontrol etmek için listeyi yazdırma
print (Ist)

##################################################################

# 13.soru Kullanıcıdan tamsayı girişi al
sayi = int(input("Bir tamsayı giriniz: "))
 
# Toplamı hesaplamak için değişken oluştur
toplam = 0
 
# 2'den başlayarak girilen tamsayıya kadar olan çift sayıları topla
for i in range(2, sayi+1, 2):
    toplam += i
 
# Sonucu ekrana yazdır
print(f"2'den {sayi}'e kadar olan çift sayıların toplamı: {toplam}")
 
##################################################################
#14.soru
import tkinter as tk
pencere=tk.Tk()
pencere.mainloop()

