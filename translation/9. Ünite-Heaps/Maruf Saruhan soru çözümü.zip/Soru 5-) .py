# Heapsort algoritması
def heapify(arr, n, i):
    smallest = i  # Kökü en küçük kabul et
    left = 2 * i + 1  # Sol çocuk
    right = 2 * i + 2  # Sağ çocuk

    # Sol çocuğun daha küçük olup olmadığını kontrol et
    if left < n and arr[left][0] < arr[smallest][0]:
        smallest = left

    # Sağ çocuğun daha küçük olup olmadığını kontrol et
    if right < n and arr[right][0] < arr[smallest][0]:
        smallest = right

    # Eğer en küçük değilse, takas yap
    if smallest != i:
        arr[i], arr[smallest] = arr[smallest], arr[i]
        heapify(arr, n, smallest)

def heapsort(arr):
    n = len(arr)
    
    # Yığını oluştur
    for i in range(n // 2 - 1, -1, -1):
        heapify(arr, n, i)

    # Yığından sırasıyla elemanları çıkar
    for i in range(n - 1, 0, -1):
        arr[i], arr[0] = arr[0], arr[i]
        heapify(arr, i, 0)

# Kruskal Algoritması
class DisjointSet:
    def __init__(self, n):
        self.parent = list(range(n))  # Her düğüm kendi kümesinin lideridir
        self.rank = [0] * n  # Her kümenin başlangıçta sıralaması sıfırdır

    def find(self, u):
        if self.parent[u] != u:
            self.parent[u] = self.find(self.parent[u])  # Yolda sıkıştırma
        return self.parent[u]

    def union(self, u, v):
        root_u = self.find(u)
        root_v = self.find(v)

        if root_u != root_v:
            # Birleştirirken sıralama kullanarak daha küçük ağacı daha büyük ağaca bağla
            if self.rank[root_u] > self.rank[root_v]:
                self.parent[root_v] = root_u
            elif self.rank[root_u] < self.rank[root_v]:
                self.parent[root_u] = root_v
            else:
                self.parent[root_v] = root_u
                self.rank[root_u] += 1


def kruskal(vertices, edges):
    # Kenarları ağırlıklarına göre sırala
    heapsort(edges)
    
    # Disjoint Set (Union-Find) yapısını başlat
    ds = DisjointSet(vertices)

    mst = []  # Minimum Spanning Tree

    # Sıralanan kenarları işle
    for weight, u, v in edges:
        # Eğer u ve v aynı kümede değilse, bu kenarı ekleyebiliriz
        if ds.find(u) != ds.find(v):
            mst.append((u, v, weight))
            ds.union(u, v)

    return mst


# Test programı
if __name__ == "__main__":
    # Kenarları (ağırlık, başlangıç, bitiş) olarak tanımlayalım
    edges = [
        (1, 0, 1),  # A-B: 1
        (4, 0, 2),  # A-C: 4
        (2, 1, 2),  # B-C: 2
        (5, 1, 3),  # B-D: 5
        (3, 2, 3)   # C-D: 3
    ]

    vertices = 4  # 4 düğüm (A, B, C, D)

    # Kruskal algoritmasını çalıştıralım
    mst = kruskal(vertices, edges)

    # Minimum Spanning Tree'yi yazdıralım
    print("Minimum Spanning Tree:")
    for u, v, weight in mst:
        print(f"{u} - {v}: {weight}")
