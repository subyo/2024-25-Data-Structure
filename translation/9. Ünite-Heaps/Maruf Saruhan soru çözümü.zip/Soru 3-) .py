import heapq

class PriorityQueue:
    def __init__(self):
        # Yığın (heap) veri yapısını oluşturuyoruz
        self.heap = []

    def enqueue(self, data, priority):
        # Öğe ve önceliği bir tuple olarak heap'e ekliyoruz
        heapq.heappush(self.heap, (priority, data))

    def dequeue(self):
        # Yığından en küçük önceliğe sahip öğeyi çıkarıyoruz
        if not self.is_empty():
            return heapq.heappop(self.heap)[1]
        else:
            raise IndexError("Dequeue from empty priority queue")

    def is_empty(self):
        # Kuyruğun boş olup olmadığını kontrol ediyoruz
        return len(self.heap) == 0

    def peek(self):
        # Kuyruğun başındaki öğeyi görme
        if not self.is_empty():
            return self.heap[0][1]
        else:
            raise IndexError("Peek from empty priority queue")

    def size(self):
        # Kuyruğun boyutunu döndürüyoruz
        return len(self.heap)

# Test programı
if __name__ == "__main__":
    pq = PriorityQueue()

    # Öncelikli kuyruğa öğeler ekliyoruz
    pq.enqueue("Araba", 3)
    pq.enqueue("Ev", 1)
    pq.enqueue("Telefon", 2)

    print("En küçük öğe (en yüksek öncelikli):", pq.peek())  # Ev, çünkü en küçük öncelik 1'dir

    # Öğeleri çıkarıyoruz ve sırasını kontrol ediyoruz
    print("Dequeued:", pq.dequeue())  # Ev
    print("Dequeued:", pq.dequeue())  # Telefon
    print("Dequeued:", pq.dequeue())  # Araba

    # Kuyruğun boş olup olmadığını kontrol ediyoruz
    print("Kuyruk boş mu?", pq.is_empty())
