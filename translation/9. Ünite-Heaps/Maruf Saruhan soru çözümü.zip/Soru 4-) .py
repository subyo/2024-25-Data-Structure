import heapq

class PriorityQueue:
    def __init__(self):
        self.heap = []
        self.entry_finder = {}  # Elemanları ve önceliklerini takip etmek için
        self.REMOVED = '<removed-task>'  # Silinmiş öğe işareti
        self.counter = 0  # Yığın içinde sıralamayı sağlamak için bir sayaç

    def enqueue(self, item, priority):
        # Eğer item zaten varsa, onu kaldırıyoruz
        if item in self.entry_finder:
            self.remove(item)
        # Sayaç ile sıralamayı sağlıyoruz
        count = self.counter
        self.counter += 1
        entry = [priority, count, item]
        self.entry_finder[item] = entry
        heapq.heappush(self.heap, entry)

    def remove(self, item):
        entry = self.entry_finder.pop(item)
        entry[-1] = self.REMOVED  # Silinmiş öğe işareti

    def dequeue(self):
        # Kuyruğun boş olup olmadığını kontrol edelim
        if not self.heap:
            raise IndexError('pop from an empty priority queue')
        
        while self.heap:
            priority, count, item = heapq.heappop(self.heap)
            if item is not self.REMOVED:
                del self.entry_finder[item]
                return item, priority
        # Eğer hiçbir geçerli öğe yoksa, yine hata verelim
        raise IndexError('pop from an empty priority queue')

    def is_empty(self):
        return len(self.heap) == 0


def dijkstra(graph, start):
    pq = PriorityQueue()
    # Başlangıç düğümünün maliyetini 0 olarak ayarlıyoruz
    pq.enqueue(start, 0)
    
    # Her düğüm için en düşük maliyet
    min_distances = {node: float('inf') for node in graph}
    min_distances[start] = 0
    
    while not pq.is_empty():
        # Kuyruktan öğe çıkarıyoruz
        current_node, current_distance = pq.dequeue()

        # Komşuları işliyoruz
        for neighbor, weight in graph[current_node].items():
            distance = current_distance + weight
            
            # Eğer komşunun yeni maliyeti daha küçükse, onu güncelliyoruz
            if distance < min_distances[neighbor]:
                min_distances[neighbor] = distance
                pq.enqueue(neighbor, distance)

    return min_distances


# Test programı
if __name__ == "__main__":
    # Grafiği tanımlıyoruz (komşuluk listesi)
    graph = {
        'A': {'B': 1, 'C': 4},
        'B': {'A': 1, 'C': 2, 'D': 5},
        'C': {'A': 4, 'B': 2, 'D': 1},
        'D': {'B': 5, 'C': 1}
    }

    # Dijkstra algoritmasını çalıştırıyoruz
    start_node = 'A'
    min_distances = dijkstra(graph, start_node)

    # Sonuçları yazdırıyoruz
    print(f"En kısa mesafeler {start_node} noktasından diğer düğümlere:")
    for node, distance in min_distances.items():
        print(f"{start_node} -> {node}: {distance}")
