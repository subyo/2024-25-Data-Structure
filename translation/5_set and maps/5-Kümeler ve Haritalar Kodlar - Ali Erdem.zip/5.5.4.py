def __add(item, items):
    idx = hash(item) % len(items)
    loc = -1

    while items[idx] is not None:
        if items[idx] == item:
            return False  # item zaten sette var

        if loc < 0 and isinstance(items[idx], HashSet.__Placeholder):
            loc = idx

        idx = (idx + 1) % len(items)

    if loc < 0:
        loc = idx

    items[loc] = item
    return True
