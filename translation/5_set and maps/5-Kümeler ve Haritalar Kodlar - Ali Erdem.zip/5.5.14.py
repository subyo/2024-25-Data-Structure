def difference_update(self, other):
    for item in other:
        self.discard(item)
