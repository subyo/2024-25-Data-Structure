def remove(self, item):
    if HashSet.__remove(item, self.items):
        self.numItems -= 1
        load = max(self.numItems, 10) / len(self.items)
        if load <= 0.25:
            self.items = HashSet.__rehash(self.items, [None] * int(len(self.items) / 2))
    else:
        raise KeyError("Item not in HashSet")
