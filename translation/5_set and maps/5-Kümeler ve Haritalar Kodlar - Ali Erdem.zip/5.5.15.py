def difference(self, other):
    result = HashSet(self)
    result.difference_update(other)
    return result
