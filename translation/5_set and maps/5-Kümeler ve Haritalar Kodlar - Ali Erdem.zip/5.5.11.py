def __contains__(self, item):
    idx = hash(item) % len(self.items)
    
    while self.items[idx] is not None:
        if self.items[idx] == item:
            return True
        
        idx = (idx + 1) % len(self.items)

    return False
