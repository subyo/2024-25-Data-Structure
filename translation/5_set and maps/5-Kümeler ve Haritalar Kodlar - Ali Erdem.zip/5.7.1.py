# One extra HashSet method for use with the HashMap class.
def __getitem__(self, item):
    idx = hash(item) % len(self.items)
    
    while self.items[idx] is not None:
        if self.items[idx] == item:
            return self.items[idx]
        
        idx = (idx + 1) % len(self.items)
    
    return None
