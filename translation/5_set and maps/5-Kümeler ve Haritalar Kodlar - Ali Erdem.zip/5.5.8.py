class __Placeholder:
    def __init__(self):
        pass

    def __eq__(self, other):
        return False

def __remove(item, items):
    idx = hash(item) % len(items)

    while items[idx] is not None:
        if items[idx] == item:
            nextIdx = (idx + 1) % len(items)
            if items[nextIdx] is None:
                items[idx] = None
            else:
                items[idx] = HashSet.__Placeholder()
            return True

        idx = (idx + 1) % len(items)

    return False
