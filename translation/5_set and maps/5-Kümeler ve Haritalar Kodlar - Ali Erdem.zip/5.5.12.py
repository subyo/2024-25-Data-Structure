def __iter__(self):
    for i in range(len(self.items)):
        if self.items[i] is not None and not isinstance(self.items[i], HashSet.__Placeholder):
            yield self.items[i]
