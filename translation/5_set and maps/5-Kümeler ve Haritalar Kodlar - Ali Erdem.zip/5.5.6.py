def __rehash(oldList, newList):
    for x in oldList:
        if x is not None and not isinstance(x, HashSet.__Placeholder):
            HashSet.__add(x, newList)
    
    return newList

def add(self, item):
    if HashSet.__add(item, self.items):
        self.numItems += 1
        load = self.numItems / len(self.items)
        if load >= 0.75:
            self.items = HashSet.__rehash(self.items, [None] * 2 * len(self.items))
